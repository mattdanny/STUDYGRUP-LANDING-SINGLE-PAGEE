import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'STUDYGRUPMAHASISWA INFO - Update Link Terbaru',
  description: 'Halaman Ini Hanya Digunakan Sebagai Info Live Update Alamat Website Apps STUDYGRUPMAHASISWA',
  openGraph: {
    title: 'STUDYGRUPMAHASISWA INFO',
    description: 'Halaman Ini Hanya Digunakan Sebagai Info Live Update Alamat Website Apps STUDYGRUPMAHASISWA',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'STUDYGRUPMAHASISWA INFO',
    description: 'Halaman Ini Hanya Digunakan Sebagai Info Live Update Alamat Website Apps STUDYGRUPMAHASISWA',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
