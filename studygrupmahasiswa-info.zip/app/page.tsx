import React from 'react';
import LogoS from '@/components/LogoS';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white text-[#2e2e2e] font-sans antialiased flex flex-col items-center">
      {/* Top thin line as seen in the reference image */}
      <div className="w-full border-t border-[#d1d5db]" />

      <main className="w-full max-w-4xl px-4 py-7 text-center">
        {/* Main Title */}
        <h1 className="font-bold text-[#2b2b2b] text-base sm:text-lg tracking-normal mb-4">
          INFO UPDATE LINK TERBARU WEBSITE STUDYGRUPMAHASISWA
        </h1>

        {/* Subtitle */}
        <p className="text-[#374151] text-sm sm:text-base leading-relaxed mb-5">
          Halaman Ini Hanya Digunakan Sebagai Info Live Update Alamat Website Apps STUDYGRUPMAHASISWA
        </p>

        {/* Instruction */}
        <p className="text-[#374151] text-sm sm:text-base mb-3">
          Silahkan klik link dibawah ini
        </p>

        {/* Primary Link */}
        <div className="mb-5">
          <a
            href="https://studygrupmahasiswaa.my.id"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#0000ee] hover:underline text-base sm:text-lg break-all"
          >
            https://studygrupmahasiswaa.my.id
          </a>
        </div>

        {/* WhatsApp Channel Section */}
        <p className="text-[#374151] text-sm sm:text-base mb-3">
          Join Whatsapp Channel :
        </p>

        <div className="mb-5">
          <a
            href="https://msha.ke/studygrupmahasiswa"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#0000ee] hover:underline text-sm sm:text-base break-all"
          >
            https://msha.ke/studygrupmahasiswa
          </a>
        </div>

        {/* Notice text 1 */}
        <p className="text-[#374151] text-sm sm:text-base mb-3">
          Apa yang sudah tertakar tidak akan tertukar ^_^
        </p>

        {/* Notice text 2 */}
        <p className="text-[#374151] text-sm sm:text-base mb-8">
          we are born to be a star &lt;/&gt;
        </p>

        {/* Long horizontal divider line across the page */}
        <hr className="w-full border-t border-[#d1d5db] my-6" />

        {/* Red "S" Logo placed under the long straight line */}
        <div className="pt-6 pb-12 flex justify-center">
          <LogoS size={180} />
        </div>
      </main>
    </div>
  );
}
