'use client';

import React, { useState } from 'react';
import Image from 'next/image';

interface LogoSProps {
  className?: string;
  size?: number;
}

export default function LogoS({ className = '', size = 180 }: LogoSProps) {
  const [imageError, setImageError] = useState(false);

  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      {!imageError ? (
        <div 
          className="relative"
          style={{ width: `${size * 0.67}px`, height: `${size}px` }}
        >
          <Image
            src="/s_logo.png"
            alt="Logo S"
            fill
            className="object-contain"
            priority
            onError={() => setImageError(true)}
          />
        </div>
      ) : (
        <svg
          width={size * 0.67}
          height={size}
          viewBox="0 0 200 300"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M 55 50 L 165 50 L 165 90 L 53 90 L 33 110 L 33 150 L 53 170 L 140 170 L 165 195 L 165 230 L 145 250 L 33 250 L 33 210 L 145 210 L 165 190 L 165 150 L 145 130 L 58 130 L 33 105 L 33 72 Z"
            fill="#E50914"
          />
        </svg>
      )}
    </div>
  );
}
